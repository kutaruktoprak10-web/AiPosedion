POSEIDON AI - Render dağıtım paketi

1) Bu klasördeki app.py, requirements.txt ve render.yaml dosyalarını GitHub'daki POSEIDON deposunun köküne yükle.
2) Render'da New + > Blueprint seçip bu depoyu bağla. Alternatif olarak New + > Web Service seç:
   Build Command: pip install -r requirements.txt
   Start Command: gunicorn app:app --workers 1 --threads 4 --timeout 120
3) Render servisinde Environment bölümünde GROQ_API_KEY adında ortam değişkeni oluşturup kendi Groq API anahtarını değer olarak ekle.
4) Deploy tamamlanınca oluşan https://...onrender.com adresini aç.

Güvenlik ve sınırlar:
- API anahtarını Python dosyasına veya GitHub'a yazma; Render Environment kullan.
- Render sürümü bulutta çalışır; telefonundaki YouTube/Chrome gibi uygulamaları açamaz.
- Notlar ve hatırlatıcılar varsayılan olarak servis dosya sisteminde tutulur. Kalıcı veri için Render Persistent Disk veya harici veritabanı gerekir; ücretsiz servislerde yeniden dağıtımda veriler kaybolabilir.
- Ücretsiz Render web servisleri bir süre kullanılmayınca uykuya geçebilir; kesin 7/24 kesintisiz çalışma garantisi yoktur.
