# -*- coding: utf-8 -*-
"""POSEIDON AI - Android'de Python ile çalışan yerel kişisel asistan paneli.
Kurulum: pip install requests
Çalıştır: python alvazar_ai_uygulama.py
Tarayıcı: http://127.0.0.1:8765
Not: Telefonun tümüne sınırsız erişim sağlamaz; Android izinleri ve uygulama sınırları geçerlidir.
"""
import ast, json, operator, os, subprocess, threading, time
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse
import requests

HOST, PORT = '127.0.0.1', 8765
GROQ_URL = 'https://api.groq.com/openai/v1/chat/completions'
MODEL = 'openai/gpt-oss-120b'
BASE = Path(__file__).resolve().parent
DATA = BASE / 'poseidon_veriler'
DATA.mkdir(exist_ok=True)
NOTES = DATA / 'notlar.json'
REMINDERS = DATA / 'hatirlaticilar.json'
HandlerKey = None
APP_PACKAGES = {'youtube':'com.google.android.youtube','chrome':'com.android.chrome','ayarlar':'com.android.settings','haritalar':'com.google.android.apps.maps','gmail':'com.google.android.gm','instagram':'com.instagram.android','discord':'com.discord','roblox':'com.roblox.client'}

def load_json(path, default):
    try: return json.loads(path.read_text(encoding='utf-8'))
    except (OSError, json.JSONDecodeError): return default

def save_json(path, data): path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')

HTML = r"""<!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#090b12"><title>Poseidon AI</title><style>
:root{color-scheme:dark;--bg:#090b12;--panel:#111522;--line:#292f45;--text:#f3f5ff;--muted:#9ca7c2;--a:#8b5cf6;--b:#22d3ee}*{box-sizing:border-box}body{margin:0;background:radial-gradient(ellipse at top,#211744,#090b12 58%);color:var(--text);font:15px system-ui,sans-serif;min-height:100vh}.app{max-width:1050px;margin:auto;padding:16px}.top{display:flex;align-items:center;gap:12px;margin-bottom:16px}.logo{width:48px;height:48px;border-radius:16px;display:grid;place-items:center;background:linear-gradient(135deg,var(--a),var(--b));font-size:25px;font-weight:900}.brand{flex:1}.brand h1{margin:0;font-size:20px;letter-spacing:1px}.brand p{margin:3px 0;color:var(--muted);font-size:12px}.status{color:#86efac;font-size:11px;border:1px solid #22543d;border-radius:20px;padding:6px 9px}.hero,.card{border:1px solid var(--line);background:#111522ed;border-radius:20px;overflow:hidden}.hero{padding:20px;margin-bottom:14px;background:linear-gradient(130deg,#19172d,#101522)}.eyebrow{font-size:11px;color:#c4b5fd;letter-spacing:2px;font-weight:700}.hero h2{font-size:25px;margin:8px 0}.hero p,.muted{color:var(--muted);line-height:1.5}.layout{display:grid;grid-template-columns:1fr;gap:14px}.head{display:flex;gap:9px;align-items:center;padding:14px;border-bottom:1px solid var(--line)}.head h3{font-size:15px;margin:0}.tag{margin-left:auto;color:#c4b5fd;background:#8b5cf61a;padding:5px 8px;border-radius:20px;font-size:11px}.chatlog{height:330px;overflow:auto;padding:14px;display:flex;flex-direction:column;gap:10px}.bubble{max-width:90%;padding:11px 13px;border-radius:15px;line-height:1.5;white-space:pre-wrap;overflow-wrap:anywhere}.bot{align-self:flex-start;background:#1a2031;border:1px solid #303750;border-bottom-left-radius:4px}.user{align-self:flex-end;background:linear-gradient(135deg,#784ce0,#4f46e5);border-bottom-right-radius:4px}.welcome{color:var(--muted);text-align:center;margin:auto;line-height:1.7;font-size:13px}.compose{display:flex;gap:8px;padding:12px;border-top:1px solid var(--line)}textarea,input,select{font:inherit;color:var(--text);background:#0b0e18;border:1px solid #303750;border-radius:12px;padding:11px;outline:none;width:100%}textarea:focus,input:focus,select:focus{border-color:var(--a)}.compose textarea{resize:vertical;min-height:45px;max-height:130px;flex:1}button{font:inherit;font-weight:700;color:white;border:0;border-radius:12px;background:linear-gradient(135deg,var(--a),#5555df);padding:11px 14px;cursor:pointer}button:disabled{opacity:.6}.inner{padding:14px}.inner p{color:var(--muted);font-size:13px;line-height:1.5}.stack{display:grid;gap:10px}.row{display:flex;gap:8px;align-items:center}.row>*{flex:1}.small{font-size:12px;color:var(--muted)}.items{font-size:13px;color:var(--muted);max-height:180px;overflow:auto}.items p{border-bottom:1px solid var(--line);padding-bottom:8px}.toolgrid{display:grid;grid-template-columns:1fr 1fr;gap:8px}.toolgrid button{background:#252b40}.notice{font-size:12px;color:#fbbf24;line-height:1.5}.foot{text-align:center;color:#68738e;font-size:11px;padding:16px}@media(min-width:760px){.app{padding:24px}.layout{grid-template-columns:1.45fr .9fr}.chatlog{height:390px}.side{display:grid;gap:14px;align-content:start}}
</style></head><body><main class="app"><header class="top"><div class="logo">P</div><div class="brand"><h1>POSEIDON AI</h1><p>Kişisel asistan · Mobil panel</p></div><div class="status">● Yerel panel</div></header><section class="hero"><div class="eyebrow">KİŞİSEL YAPAY ZEKÂ</div><h2>Merhaba, ben Poseidon.</h2><p>Sohbet et, notlarını ve hatırlatıcılarını yönet, yardımcı araçları kullan.</p></section>
<section class="card" style="margin-bottom:14px">
<div class="head"><span>◈</span><h3>POSEIDON Kontrol Merkezi</h3><span class="tag">AGENCY / SYSTEM HUB</span></div>
<div class="inner">
<p>Asistan modüllerini tek panelden yönet. Android izinleri yalnızca cihazın Ayarlar ekranından, sen onay verdiğinde açılır.</p>
<div class="toolgrid">
<button type="button" id="permInfoBtn">İzin rehberi</button><button type="button" id="systemInfoBtn">Sistem durumu</button>
<button type="button" id="agencyBtn">Ajans modülleri</button><button type="button" id="privacyBtn">Gizlilik kontrolü</button>
</div>
<div id="controlout" class="items" style="margin-top:12px"><strong>Modüller</strong><p>AI sohbeti · Notlar · Hatırlatıcılar · Hava durumu · Hesap makinesi · Uygulama açıcı</p></div>
<div class="notice">Bu Python paneli Android izinlerini kendiliğinden veremez. SMS, arama kayıtları, mikrofon, dosyalar ve bildirimler için uygun Android izinleri ve uygulama entegrasyonu gerekir. Sınırsız telefon erişimi yoktur.</div>
</div></section>
<section class="layout"><div class="card"><div class="head"><span>✦</span><h3>Poseidon ile sohbet</h3><span class="tag">GROQ AI</span></div><div id="log" class="chatlog"><div class="welcome">Bir şey sormaya hazır mısın?<br>Örn. “Bana bir çalışma planı hazırla.”</div></div><form id="form" class="compose"><textarea id="q" placeholder="Poseidon'a mesaj yaz..." required></textarea><button id="send">Gönder ➤</button></form></div><aside class="side"><div class="card"><div class="head"><span>⚙</span><h3>AI bağlantısı</h3></div><div class="inner"><p>Groq API anahtarını gir. Anahtar yalnızca bu Python işlemi açıkken bellekte tutulur.</p><div class="stack"><input id="key" type="password" autocomplete="off" placeholder="gsk_..."><button id="save">Anahtarı kullan</button></div><p id="keymsg" class="items">Henüz anahtar girilmedi.</p><div class="notice">API anahtarını kimseyle paylaşma. Bu yerel paneli internete açma.</div></div></div>
<div class="card"><div class="head"><span>⌁</span><h3>Hızlı araçlar</h3></div><div class="inner"><div class="toolgrid"><button id="timeBtn">Saat / tarih</button><button id="weatherBtn">Hava durumu</button><button id="calcBtn">Hesap makinesi</button><button id="appsBtn">Uygulama aç</button></div><div id="toolout" class="items" style="margin-top:12px"></div><div id="appbox" class="stack" style="display:none;margin-top:10px"><select id="appname"><option value="youtube">YouTube</option><option value="chrome">Chrome</option><option value="ayarlar">Ayarlar</option><option value="haritalar">Haritalar</option><option value="gmail">Gmail</option><option value="instagram">Instagram</option><option value="discord">Discord</option><option value="roblox">Roblox</option></select><button id="launch">Seçili uygulamayı aç</button></div><div id="calcbox" class="stack" style="display:none;margin-top:10px"><input id="expr" placeholder="(12 + 8) * 3"><button id="calculate">Hesapla</button></div><div id="weatherbox" class="stack" style="display:none;margin-top:10px"><input id="city" placeholder="Şehir (örn. İstanbul)"><button id="getweather">Hava durumunu getir</button></div></div></div></aside></section>
<section class="layout" style="margin-top:14px"><div class="card"><div class="head"><span>▤</span><h3>Notlar</h3></div><div class="inner"><div class="stack"><textarea id="note" placeholder="Notunu yaz..."></textarea><button id="saveNote">Notu kaydet</button></div><div id="notes" class="items" style="margin-top:10px">Notlar yükleniyor...</div></div></div><div class="card"><div class="head"><span>◷</span><h3>Hatırlatıcılar</h3></div><div class="inner"><div class="stack"><input id="remtext" placeholder="Hatırlatıcı metni"><label class="small">Tarih ve saat</label><input id="remwhen" type="datetime-local"><button id="saveReminder">Hatırlatıcı ekle</button></div><p class="small">Bildirim kontrolü Python programı çalışırken yapılır; Android pil kısıtlamaları etkileyebilir.</p><div id="reminders" class="items">Hatırlatıcılar yükleniyor...</div></div></div></section><div class="foot">POSEIDON AI · Telefonda yerel çalışan Python paneli</div></main>
<script>
const log=document.getElementById('log'),q=document.getElementById('q'),send=document.getElementById('send');let history=[];
const controlout=document.getElementById('controlout');
document.getElementById('permInfoBtn').onclick=()=>{controlout.textContent='İZİN REHBERİ — Android Ayarlar > Uygulamalar > Pydroid 3 > İzinler bölümünü aç. Yalnızca gerçekten kullanacağın izinleri etkinleştir. Mikrofon, kamera, kişiler, SMS ve arama kayıtları gibi hassas izinler bu panel tarafından otomatik verilmez.'};
document.getElementById('systemInfoBtn').onclick=async()=>{try{const d=await api('/api/status');controlout.textContent='Sistem: Python sunucusu erişilebilir. Groq API anahtarı: '+(d.key?'oturumda ayarlı':'henüz ayarlı değil')+'. Notlar ve hatırlatıcılar yerel veri klasöründe tutulur.'}catch(e){controlout.textContent='Durum alınamadı: '+e.message}};
document.getElementById('agencyBtn').onclick=()=>{controlout.textContent='AGENCY MODÜLLERİ — 1) AI beyin (Groq) 2) Kişisel organizasyon (notlar/hatırlatıcılar) 3) Bilgi araçları (hava durumu/hesap makinesi) 4) Uygulama başlatıcı 5) Gizlilik ve izin kontrolü. Yeni modüller için ayrıca güvenli entegrasyon gerekir.'};
document.getElementById('privacyBtn').onclick=()=>{controlout.textContent='GİZLİLİK — API anahtarını paylaşma. Bu paneli internete açma. Hassas verileri sohbete yazma. Uygulama açma dışında telefon işlemleri otomatik yapılmaz; e-posta gönderme, arama kayıtları ve SMS için ayrıca güvenli izin/entegrasyon gerekir.'};

function bubble(t,c){let e=document.createElement('div');e.className='bubble '+c;e.textContent=t;log.appendChild(e);log.scrollTop=log.scrollHeight;return e}
async function api(path,body){let r=await fetch(path,{method:body?'POST':'GET',headers:body?{'Content-Type':'application/json'}:{},body:body?JSON.stringify(body):undefined});let d=await r.json();if(!r.ok||d.ok===false)throw Error(d.error||'İşlem başarısız');return d}
document.getElementById('save').onclick=async()=>{let key=document.getElementById('key').value.trim(),m=document.getElementById('keymsg');if(!key){m.textContent='Önce API anahtarını gir.';return}try{await api('/api/key',{key});m.textContent='API anahtarı bu oturum için ayarlandı.';document.getElementById('key').value=''}catch(e){m.textContent='Hata: '+e.message}};
document.getElementById('form').onsubmit=async e=>{e.preventDefault();let t=q.value.trim();if(!t)return;bubble(t,'user');history.push({role:'user',content:t});q.value='';send.disabled=true;send.textContent='...';let w=bubble('Düşünüyorum…','bot');try{let d=await api('/api/chat',{messages:history});w.remove();bubble(d.answer,'bot');history.push({role:'assistant',content:d.answer});history=history.slice(-12)}catch(err){w.textContent='Hata: '+err.message;history.pop()}finally{send.disabled=false;send.textContent='Gönder ➤'}};
q.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();document.getElementById('form').requestSubmit()}});
async function loadNotes(){try{let d=await api('/api/notes'),el=document.getElementById('notes');el.replaceChildren();if(!d.notes.length){el.textContent='Henüz not yok.';return}d.notes.slice().reverse().forEach((n,i)=>{let p=document.createElement('p');p.textContent='• '+n.text+' ('+n.created+')';el.appendChild(p)})}catch(e){document.getElementById('notes').textContent=e.message}}
document.getElementById('saveNote').onclick=async()=>{let t=document.getElementById('note').value.trim();if(!t)return;try{await api('/api/notes',{text:t});document.getElementById('note').value='';loadNotes()}catch(e){alert(e.message)}};
async function loadReminders(){try{let d=await api('/api/reminders'),el=document.getElementById('reminders');el.replaceChildren();if(!d.reminders.length){el.textContent='Henüz hatırlatıcı yok.';return}d.reminders.slice().reverse().forEach((n)=>{let p=document.createElement('p');p.textContent=(n.done?'✓ ':'◷ ')+n.text+' — '+n.when.replace('T',' ');el.appendChild(p)})}catch(e){document.getElementById('reminders').textContent=e.message}}
document.getElementById('saveReminder').onclick=async()=>{let text=document.getElementById('remtext').value.trim(),when=document.getElementById('remwhen').value;if(!text||!when){alert('Metin ve tarih/saat gir.');return}try{await api('/api/reminders',{text,when});document.getElementById('remtext').value='';loadReminders()}catch(e){alert(e.message)}};
document.getElementById('timeBtn').onclick=async()=>{try{let d=await api('/api/time');document.getElementById('toolout').textContent=d.value}catch(e){document.getElementById('toolout').textContent=e.message}};
document.getElementById('weatherBtn').onclick=()=>{document.getElementById('weatherbox').style.display='grid';document.getElementById('calcbox').style.display='none';document.getElementById('appbox').style.display='none'};
document.getElementById('getweather').onclick=async()=>{try{let d=await api('/api/weather',{city:document.getElementById('city').value.trim()});document.getElementById('toolout').textContent=`${d.city}: ${d.temp}°C, hissedilen ${d.feels}°C, nem %${d.humidity}, rüzgâr ${d.wind} km/sa`}catch(e){document.getElementById('toolout').textContent='Hata: '+e.message}};
document.getElementById('calcBtn').onclick=()=>{document.getElementById('calcbox').style.display='grid';document.getElementById('weatherbox').style.display='none';document.getElementById('appbox').style.display='none'};
document.getElementById('calculate').onclick=async()=>{try{let d=await api('/api/calc',{expression:document.getElementById('expr').value});document.getElementById('toolout').textContent='Sonuç: '+d.result}catch(e){document.getElementById('toolout').textContent='Hata: '+e.message}};
document.getElementById('appsBtn').onclick=()=>{document.getElementById('appbox').style.display='grid';document.getElementById('calcbox').style.display='none';document.getElementById('weatherbox').style.display='none'};
document.getElementById('launch').onclick=async()=>{try{let d=await api('/api/open-app',{name:document.getElementById('appname').value});document.getElementById('toolout').textContent=d.message}catch(e){document.getElementById('toolout').textContent='Hata: '+e.message}};
loadNotes();loadReminders();
</script></body></html>"""

OPS={ast.Add:operator.add,ast.Sub:operator.sub,ast.Mult:operator.mul,ast.Div:operator.truediv,ast.FloorDiv:operator.floordiv,ast.Mod:operator.mod,ast.Pow:operator.pow,ast.UAdd:operator.pos,ast.USub:operator.neg}
def calc_node(n):
    if isinstance(n,ast.Expression): return calc_node(n.body)
    if isinstance(n,ast.Constant) and type(n.value) in (int,float): return n.value
    if isinstance(n,ast.BinOp) and type(n.op) in OPS:
        a,b=calc_node(n.left),calc_node(n.right)
        if isinstance(n.op,ast.Pow) and (abs(b)>100 or abs(a)>1e100): raise ValueError('Üs veya sayı çok büyük.')
        result=OPS[type(n.op)](a,b)
        if abs(result)>1e100: raise ValueError('Sonuç çok büyük.')
        return result
    if isinstance(n,ast.UnaryOp) and type(n.op) in OPS: return OPS[type(n.op)](calc_node(n.operand))
    raise ValueError('Yalnızca temel matematik işlemleri desteklenir.')

def reminder_worker():
    while True:
        try:
            items=load_json(REMINDERS,[]); changed=False; now=datetime.now()
            for item in items:
                if item.get('done') or item.get('notified'): continue
                try: due=datetime.strptime(item['when'],'%Y-%m-%d %H:%M')
                except (ValueError,KeyError): continue
                if due<=now:
                    try:
                        from plyer import notification
                        notification.notify(title='Poseidon AI hatırlatıcı',message=item.get('text','Hatırlatıcı'),timeout=10)
                    except Exception: print('[POSEIDON HATIRLATICI]',item.get('text','Hatırlatıcı'))
                    item['notified']=True;changed=True
            if changed: save_json(REMINDERS,items)
        except Exception as e: print('Hatırlatıcı kontrolü:',e)
        time.sleep(15)

class Handler(BaseHTTPRequestHandler):
    api_key=None
    def log_message(self,*args): pass
    def send_json(self,code,obj):
        raw=json.dumps(obj,ensure_ascii=False).encode();self.send_response(code);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(raw)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(raw)
    def read_body(self):
        size=int(self.headers.get('Content-Length','0'))
        if size>100000: raise ValueError('İstek çok büyük.')
        return json.loads(self.rfile.read(size).decode() or '{}')
    def do_GET(self):
        path=urlparse(self.path).path
        if path=='/':
            raw=HTML.encode();self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
        elif path=='/api/notes': self.send_json(200,{'ok':True,'notes':load_json(NOTES,[])})
        elif path=='/api/reminders': self.send_json(200,{'ok':True,'reminders':load_json(REMINDERS,[])})
        elif path=='/api/status': self.send_json(200,{'ok':True,'key':bool(Handler.api_key)})
        elif path=='/api/time': self.send_json(200,{'ok':True,'value':datetime.now().strftime('%d.%m.%Y %H:%M:%S')})
        else: self.send_json(404,{'ok':False,'error':'Bulunamadı.'})
    def do_POST(self):
        try: body=self.read_body()
        except Exception: self.send_json(400,{'ok':False,'error':'Geçersiz veri.'});return
        path=urlparse(self.path).path
        try:
            if path=='/api/key':
                key=str(body.get('key','')).strip()
                if not key.startswith('gsk_') or len(key)<20: raise ValueError('Groq API anahtarı geçersiz görünüyor.')
                Handler.api_key=key; self.send_json(200,{'ok':True})
            elif path=='/api/chat':
                if not Handler.api_key: raise ValueError('Önce Groq API anahtarını ayarla.')
                msgs=[{'role':'system','content':'Sen POSEIDON AI adlı gelişmiş Türkçe kişisel asistansın. Güvenilir, net ve profesyonel ol. Kullanıcının açık onayı olmadan telefonunda işlem yaptığını iddia etme. Açık, faydalı ve güvenli cevaplar ver. Telefonun tümüne sınırsız erişimin olduğunu iddia etme. Telefon işlemleri için kullanıcı onayı ve Android izinleri gerektiğini açıkla.'}]
                for m in body.get('messages',[])[-12:]:
                    if isinstance(m,dict) and m.get('role') in ('user','assistant') and isinstance(m.get('content'),str): msgs.append({'role':m['role'],'content':m['content'][:8000]})
                r=requests.post(GROQ_URL,headers={'Authorization':'Bearer '+Handler.api_key,'Content-Type':'application/json'},json={'model':MODEL,'messages':msgs,'temperature':0.7,'max_tokens':1200},timeout=60)
                try: data=r.json()
                except ValueError: data={}
                if not r.ok: raise RuntimeError(str(data.get('error',{}).get('message','HTTP '+str(r.status_code)))[:400])
                answer=data.get('choices',[{}])[0].get('message',{}).get('content','') or 'Yanıt alınamadı.'
                self.send_json(200,{'ok':True,'answer':answer})
            elif path=='/api/notes':
                text=str(body.get('text','')).strip()
                if not text or len(text)>2000: raise ValueError('Not boş olamaz ve 2000 karakteri geçemez.')
                notes=load_json(NOTES,[]);notes.append({'text':text,'created':datetime.now().strftime('%d.%m.%Y %H:%M')});save_json(NOTES,notes[-300:]);self.send_json(200,{'ok':True})
            elif path=='/api/reminders':
                text=str(body.get('text','')).strip(); raw=str(body.get('when','')).strip()
                try: when=datetime.strptime(raw,'%Y-%m-%dT%H:%M').strftime('%Y-%m-%d %H:%M')
                except ValueError: raise ValueError('Tarih ve saati kontrol et.')
                if not text or len(text)>500: raise ValueError('Hatırlatıcı metni boş olamaz ve 500 karakteri geçemez.')
                items=load_json(REMINDERS,[]);items.append({'text':text,'when':when,'done':False,'notified':False});save_json(REMINDERS,items[-300:]);self.send_json(200,{'ok':True})
            elif path=='/api/calc':
                expr=str(body.get('expression','')).strip()
                if not expr or len(expr)>120: raise ValueError('İşlem boş veya çok uzun.')
                result=calc_node(ast.parse(expr,mode='eval'));self.send_json(200,{'ok':True,'result':result})
            elif path=='/api/weather':
                city=str(body.get('city','')).strip()
                if not city: raise ValueError('Şehir adı gir.')
                geo=requests.get('https://geocoding-api.open-meteo.com/v1/search',params={'name':city,'count':1,'language':'tr','format':'json'},timeout=15);geo.raise_for_status();results=geo.json().get('results',[])
                if not results: raise ValueError('Şehir bulunamadı.')
                place=results[0]; w=requests.get('https://api.open-meteo.com/v1/forecast',params={'latitude':place['latitude'],'longitude':place['longitude'],'current':'temperature_2m,relative_humidity_2m,apparent_temperature,wind_speed_10m','timezone':'auto'},timeout=15);w.raise_for_status();c=w.json().get('current',{})
                self.send_json(200,{'ok':True,'city':place.get('name',city),'temp':c.get('temperature_2m'),'feels':c.get('apparent_temperature'),'humidity':c.get('relative_humidity_2m'),'wind':c.get('wind_speed_10m')})
            elif path=='/api/open-app':
                name=str(body.get('name','')).lower();package=APP_PACKAGES.get(name)
                if not package: raise ValueError('Bu uygulama listede yok.')
                if os.name!='posix' or not (Path('/system/bin').exists() or 'ANDROID_ROOT' in os.environ): raise ValueError('Uygulama açma özelliği yalnızca destekleyen Android Python ortamlarında çalışır.')
                result=subprocess.run(['monkey','-p',package,'1'],capture_output=True,text=True,timeout=8)
                if result.returncode!=0: raise RuntimeError('Açılamadı. Uygulama kurulu olmayabilir veya Android erişimi engelliyor olabilir.')
                self.send_json(200,{'ok':True,'message':name+' için açma isteği gönderildi.'})
            else: self.send_json(404,{'ok':False,'error':'Bulunamadı.'})
        except (ValueError, SyntaxError, ZeroDivisionError, OverflowError) as e: self.send_json(400,{'ok':False,'error':str(e)})
        except requests.RequestException as e: self.send_json(502,{'ok':False,'error':'Bağlantı hatası: '+str(e)[:250]})
        except Exception as e: self.send_json(502,{'ok':False,'error':str(e)[:400]})

def main():
    threading.Thread(target=reminder_worker,daemon=True).start()
    server=ThreadingHTTPServer((HOST,PORT),Handler)
    print('\nPOSEIDON AI - MOBİL KONTROL PANELİ')
    print('Panel: http://127.0.0.1:8765')
    print('Durdurmak için Ctrl+C')
    try: server.serve_forever()
    except KeyboardInterrupt: print('\nPoseidon kapatıldı.')
    finally: server.server_close()
if __name__=='__main__': main()
